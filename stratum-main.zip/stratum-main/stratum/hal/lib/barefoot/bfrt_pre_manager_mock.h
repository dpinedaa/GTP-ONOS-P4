// Copyright 2021-present Open Networking Foundation
// SPDX-License-Identifier: Apache-2.0

#ifndef STRATUM_HAL_LIB_BAREFOOT_BFRT_PRE_MANAGER_MOCK_H_
#define STRATUM_HAL_LIB_BAREFOOT_BFRT_PRE_MANAGER_MOCK_H_

#include <memory>

#include "gmock/gmock.h"
#include "stratum/hal/lib/barefoot/bfrt_pre_manager.h"

namespace stratum {
namespace hal {
namespace barefoot {

class BfrtPreManagerMock : public BfrtPreManager {
 public:
  // MOCK_METHOD1(PushChassisConfig,
  //              ::util::Status(const BfrtDeviceConfig& config, uint64
  //              node_id));
  // MOCK_METHOD2(VerifyChassisConfig,
  //              ::util::Status(const ChassisConfig& config, uint64 node_id));
  MOCK_METHOD1(PushForwardingPipelineConfig,
               ::util::Status(const BfrtDeviceConfig& config));
  MOCK_METHOD1(VerifyForwardingPipelineConfig,
               ::util::Status(const BfrtDeviceConfig& config));
  MOCK_METHOD3(WritePreEntry,
               ::util::Status(
                   std::shared_ptr<BfSdeInterface::SessionInterface> session,
                   const ::p4::v1::Update::Type& type, const PreEntry& entry));
  MOCK_METHOD3(
      ReadPreEntry,
      ::util::Status(std::shared_ptr<BfSdeInterface::SessionInterface> session,
                     const PreEntry& entry,
                     WriterInterface<::p4::v1::ReadResponse>* writer));
};

}  // namespace barefoot
}  // namespace hal
}  // namespace stratum

#endif  // STRATUM_HAL_LIB_BAREFOOT_BFRT_PRE_MANAGER_MOCK_H_
