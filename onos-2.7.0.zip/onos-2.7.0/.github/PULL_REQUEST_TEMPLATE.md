
ONOS project does not use GitHub features for code contribution.

Please submit a patch to [ONOS gerrit](https://gerrit.onosproject.org/).

You will need to register to submit a patch.
If you do not have ONOS project account yet, you can create one here
https://onosproject.org/register/

More information about how you can contribute can be found on the wiki:
https://wiki.onosproject.org/display/ONOS/Contributor+Guide

